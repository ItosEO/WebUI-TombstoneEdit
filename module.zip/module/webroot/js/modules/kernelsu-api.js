/**
 * KernelSU API包装器
 * 提供统一的KernelSU API访问接口
 */

class KernelSUAPI {
    constructor() {
        this.isAvailable = false;
        this.api = null;
        this.initPromise = this.initialize();
    }

    /**
     * 初始化KernelSU API
     */
    async initialize() {
        try {
            // 检查是否在KernelSU环境中
            if (typeof window !== 'undefined' && window.ksu) {
                this.api = window.ksu;
                this.isAvailable = true;
                console.log('KernelSU API已通过全局对象加载');
                return true;
            }

            // 尝试动态导入
            try {
                const kernelsu = await import('kernelsu');
                this.api = kernelsu;
                this.isAvailable = true;
                console.log('KernelSU API已通过模块导入加载');
                return true;
            } catch (importError) {
                console.warn('无法导入KernelSU模块:', importError.message);
            }

            // 检查是否有其他方式访问API
            if (typeof exec === 'function') {
                this.api = { exec, spawn, toast, fullScreen };
                this.isAvailable = true;
                console.log('KernelSU API已通过全局函数加载');
                return true;
            }

            throw new Error('KernelSU API不可用');

        } catch (error) {
            console.error('KernelSU API初始化失败:', error);
            this.isAvailable = false;
            return false;
        }
    }

    /**
     * 等待API初始化完成
     */
    async waitForReady() {
        return await this.initPromise;
    }

    /**
     * 检查API是否可用
     */
    isReady() {
        return this.isAvailable;
    }

    /**
     * 执行shell命令
     * @param {string} command - 命令
     * @param {Object} options - 选项
     * @param {string} input - 输入数据
     * @returns {Promise<Object>} 执行结果
     */
    async exec(command, options = {}, input = '') {
        await this.waitForReady();
        
        if (!this.isAvailable) {
            throw new Error('KernelSU API不可用');
        }

        try {
            if (input) {
                // 如果有输入数据，使用管道方式
                const result = await this.api.exec(`echo '${input}' | ${command}`, options);
                return result;
            } else {
                return await this.api.exec(command, options);
            }
        } catch (error) {
            console.error('命令执行失败:', error);
            throw error;
        }
    }

    /**
     * 生成进程
     * @param {string} command - 命令
     * @param {Array} args - 参数
     * @param {Object} options - 选项
     * @returns {Promise<Object>} 子进程对象
     */
    async spawn(command, args = [], options = {}) {
        await this.waitForReady();
        
        if (!this.isAvailable) {
            throw new Error('KernelSU API不可用');
        }

        return await this.api.spawn(command, args, options);
    }

    /**
     * 显示Toast消息
     * @param {string} message - 消息内容
     */
    async toast(message) {
        await this.waitForReady();
        
        if (!this.isAvailable) {
            console.log(`Toast: ${message}`);
            return;
        }

        try {
            await this.api.toast(message);
        } catch (error) {
            console.warn('Toast显示失败:', error);
            console.log(`Toast: ${message}`);
        }
    }

    /**
     * 切换全屏模式
     * @param {boolean} fullscreen - 是否全屏
     */
    async fullScreen(fullscreen = true) {
        await this.waitForReady();
        
        if (!this.isAvailable) {
            console.log(`全屏模式: ${fullscreen}`);
            return;
        }

        try {
            await this.api.fullScreen(fullscreen);
        } catch (error) {
            console.warn('全屏切换失败:', error);
        }
    }

    /**
     * 写入文件
     * @param {string} path - 文件路径
     * @param {string} content - 文件内容
     * @returns {Promise<Object>} 执行结果
     */
    async writeFile(path, content) {
        const escapedContent = content.replace(/'/g, "'\"'\"'");
        return await this.exec(`cat > '${path}'`, {}, escapedContent);
    }

    /**
     * 读取文件
     * @param {string} path - 文件路径
     * @returns {Promise<string>} 文件内容
     */
    async readFile(path) {
        const result = await this.exec(`cat '${path}'`);
        if (result.errno !== 0) {
            throw new Error(`读取文件失败: ${result.stderr || '未知错误'}`);
        }
        return result.stdout;
    }

    /**
     * 检查文件是否存在
     * @param {string} path - 文件路径
     * @returns {Promise<boolean>} 文件是否存在
     */
    async fileExists(path) {
        try {
            const result = await this.exec(`test -f '${path}'`);
            return result.errno === 0;
        } catch (error) {
            return false;
        }
    }

    /**
     * 创建目录
     * @param {string} path - 目录路径
     * @param {boolean} recursive - 是否递归创建
     * @returns {Promise<Object>} 执行结果
     */
    async mkdir(path, recursive = true) {
        const command = recursive ? `mkdir -p '${path}'` : `mkdir '${path}'`;
        return await this.exec(command);
    }

    /**
     * 复制文件
     * @param {string} source - 源文件路径
     * @param {string} destination - 目标文件路径
     * @returns {Promise<Object>} 执行结果
     */
    async copyFile(source, destination) {
        return await this.exec(`cp '${source}' '${destination}'`);
    }

    /**
     * 移动文件
     * @param {string} source - 源文件路径
     * @param {string} destination - 目标文件路径
     * @returns {Promise<Object>} 执行结果
     */
    async moveFile(source, destination) {
        return await this.exec(`mv '${source}' '${destination}'`);
    }

    /**
     * 删除文件
     * @param {string} path - 文件路径
     * @returns {Promise<Object>} 执行结果
     */
    async removeFile(path) {
        return await this.exec(`rm -f '${path}'`);
    }

    /**
     * 设置文件权限
     * @param {string} path - 文件路径
     * @param {string} mode - 权限模式
     * @returns {Promise<Object>} 执行结果
     */
    async chmod(path, mode) {
        return await this.exec(`chmod ${mode} '${path}'`);
    }

    /**
     * 设置文件所有者
     * @param {string} path - 文件路径
     * @param {string} owner - 所有者
     * @returns {Promise<Object>} 执行结果
     */
    async chown(path, owner) {
        return await this.exec(`chown ${owner} '${path}'`);
    }

    /**
     * 获取文件状态
     * @param {string} path - 文件路径
     * @returns {Promise<Object>} 文件状态信息
     */
    async stat(path) {
        const result = await this.exec(`stat '${path}'`);
        if (result.errno !== 0) {
            throw new Error(`获取文件状态失败: ${result.stderr || '未知错误'}`);
        }
        return this.parseStatOutput(result.stdout);
    }

    /**
     * 解析stat命令输出
     * @param {string} output - stat命令输出
     * @returns {Object} 解析后的文件信息
     */
    parseStatOutput(output) {
        const info = {};
        
        // 解析文件大小
        const sizeMatch = output.match(/Size:\s+(\d+)/);
        if (sizeMatch) {
            info.size = parseInt(sizeMatch[1]);
        }

        // 解析修改时间
        const modifyMatch = output.match(/Modify:\s+([^\n]+)/);
        if (modifyMatch) {
            info.lastModified = modifyMatch[1].trim();
        }

        // 解析权限
        const modeMatch = output.match(/Access:\s+\((\d+)/);
        if (modeMatch) {
            info.mode = modeMatch[1];
        }

        return info;
    }

    /**
     * 列出目录内容
     * @param {string} path - 目录路径
     * @param {boolean} detailed - 是否显示详细信息
     * @returns {Promise<Array>} 目录内容列表
     */
    async listDirectory(path, detailed = false) {
        const command = detailed ? `ls -la '${path}'` : `ls '${path}'`;
        const result = await this.exec(command);
        
        if (result.errno !== 0) {
            throw new Error(`列出目录失败: ${result.stderr || '未知错误'}`);
        }

        return result.stdout.trim().split('\n').filter(line => line.trim());
    }
}

// 创建全局实例
const kernelSUAPI = new KernelSUAPI();

export default kernelSUAPI;
