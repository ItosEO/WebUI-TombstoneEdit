/**
 * 文件管理器模块
 * 负责配置文件的读写、备份和恢复操作
 */

import kernelSUAPI from './kernelsu-api.js';

export class FileManager {
    constructor() {
        // 配置文件路径
        this.configPath = '/data/oplus/os/bpm/sys_elsa_config_list.xml';
        this.backupDir = '/data/local/tmp/tombstone_backups';
        this.tempDir = '/data/local/tmp/tombstone_temp';
        
        // 确保备份目录存在
        this.initializeDirectories();
    }

    /**
     * 初始化必要的目录
     */
    async initializeDirectories() {
        try {
            // 创建备份目录
            await kernelSUAPI.mkdir(this.backupDir, true);
            await kernelSUAPI.mkdir(this.tempDir, true);

            // 设置目录权限
            await kernelSUAPI.chmod(this.backupDir, '755');
            await kernelSUAPI.chmod(this.tempDir, '755');

            console.log('目录初始化完成');
        } catch (error) {
            console.warn('目录初始化警告:', error.message);
        }
    }

    /**
     * 检查Root权限
     * @returns {boolean} 是否有Root权限
     */
    async checkRootAccess() {
        try {
            const result = await kernelSUAPI.exec('id');
            return result.errno === 0 && result.stdout.includes('uid=0');
        } catch (error) {
            console.error('Root权限检查失败:', error);
            return false;
        }
    }

    /**
     * 检查配置文件是否存在
     * @returns {boolean} 文件是否存在
     */
    async checkConfigFileExists() {
        try {
            return await kernelSUAPI.fileExists(this.configPath);
        } catch (error) {
            return false;
        }
    }

    /**
     * 读取配置文件内容
     * @returns {string} 文件内容
     */
    async readConfigFile() {
        try {
            // 检查文件是否存在
            const exists = await this.checkConfigFileExists();
            if (!exists) {
                throw new Error(`配置文件不存在: ${this.configPath}`);
            }

            // 读取文件内容
            const content = await kernelSUAPI.readFile(this.configPath);

            if (!content || content.trim().length === 0) {
                throw new Error('配置文件为空');
            }

            console.log('配置文件读取成功');
            return content;

        } catch (error) {
            console.error('读取配置文件失败:', error);
            throw new Error(`读取配置文件失败: ${error.message}`);
        }
    }

    /**
     * 写入配置文件
     * @param {string} content - 文件内容
     */
    async writeConfigFile(content) {
        try {
            if (!content || content.trim().length === 0) {
                throw new Error('配置内容不能为空');
            }

            // 创建临时文件
            const tempFile = `${this.tempDir}/config_temp_${Date.now()}.xml`;

            // 写入临时文件
            await kernelSUAPI.writeFile(tempFile, content);

            // 验证临时文件
            const exists = await kernelSUAPI.fileExists(tempFile);
            if (!exists) {
                throw new Error('临时文件验证失败');
            }

            // 备份原文件
            if (await this.checkConfigFileExists()) {
                const backupPath = await this.createBackup();
                console.log(`原配置文件已备份到: ${backupPath}`);
            }

            // 复制临时文件到目标位置
            await kernelSUAPI.copyFile(tempFile, this.configPath);

            // 设置文件权限
            await kernelSUAPI.chmod(this.configPath, '644');
            await kernelSUAPI.chown(this.configPath, 'system:system');

            // 清理临时文件
            await kernelSUAPI.removeFile(tempFile);

            console.log('配置文件写入成功');

        } catch (error) {
            console.error('写入配置文件失败:', error);
            throw new Error(`写入配置文件失败: ${error.message}`);
        }
    }

    /**
     * 创建配置文件备份
     * @returns {string} 备份文件路径
     */
    async createBackup() {
        try {
            // 检查原文件是否存在
            const exists = await this.checkConfigFileExists();
            if (!exists) {
                throw new Error('原配置文件不存在，无法创建备份');
            }

            // 生成备份文件名
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const backupPath = `${this.backupDir}/sys_elsa_config_list_${timestamp}.xml`;

            // 复制文件
            await kernelSUAPI.copyFile(this.configPath, backupPath);

            // 设置备份文件权限
            await kernelSUAPI.chmod(backupPath, '644');

            // 清理旧备份（保留最近10个）
            await this.cleanOldBackups();

            console.log(`备份创建成功: ${backupPath}`);
            return backupPath;

        } catch (error) {
            console.error('创建备份失败:', error);
            throw new Error(`创建备份失败: ${error.message}`);
        }
    }

    /**
     * 获取备份文件列表
     * @returns {Array} 备份文件列表
     */
    async getBackupList() {
        try {
            const files = await kernelSUAPI.listDirectory(this.backupDir, true);

            const backups = [];

            for (const line of files) {
                if (line.includes('sys_elsa_config_list_') && line.includes('.xml')) {
                    const parts = line.split(/\s+/);
                    const filename = parts[parts.length - 1];
                    const filepath = `${this.backupDir}/${filename}`;

                    // 提取时间戳
                    const timestampMatch = filename.match(/sys_elsa_config_list_(.+)\.xml/);
                    if (timestampMatch) {
                        const timestamp = timestampMatch[1].replace(/-/g, ':');

                        // 获取文件详细信息
                        try {
                            const stat = await kernelSUAPI.stat(filepath);
                            backups.push({
                                path: filepath,
                                filename: filename,
                                timestamp: timestamp,
                                size: stat.size || 0,
                                lastModified: stat.lastModified || 'Unknown',
                                mode: stat.mode || '644'
                            });
                        } catch (statError) {
                            // 如果获取stat失败，仍然添加基本信息
                            backups.push({
                                path: filepath,
                                filename: filename,
                                timestamp: timestamp,
                                size: parts[4] || '0',
                                lastModified: `${parts[5] || ''} ${parts[6] || ''} ${parts[7] || ''}`.trim(),
                                mode: 'unknown'
                            });
                        }
                    }
                }
            }

            // 按时间戳排序（最新的在前）
            backups.sort((a, b) => b.timestamp.localeCompare(a.timestamp));

            return backups;

        } catch (error) {
            console.error('获取备份列表失败:', error);
            return [];
        }
    }

    /**
     * 恢复指定的备份文件
     * @param {string} backupPath - 备份文件路径
     */
    async restoreBackup(backupPath = null) {
        try {
            let targetBackup = backupPath;

            // 如果没有指定备份文件，使用最新的备份
            if (!targetBackup) {
                const backups = await this.getBackupList();
                if (backups.length === 0) {
                    throw new Error('没有找到可用的备份文件');
                }
                targetBackup = backups[0].path;
            }

            // 检查备份文件是否存在
            const backupExists = await kernelSUAPI.fileExists(targetBackup);
            if (!backupExists) {
                throw new Error(`备份文件不存在: ${targetBackup}`);
            }

            // 验证备份文件内容
            const content = await kernelSUAPI.readFile(targetBackup);
            if (!content.includes('<?xml')) {
                throw new Error('备份文件格式无效');
            }

            // 恢复文件
            await kernelSUAPI.copyFile(targetBackup, this.configPath);

            // 设置文件权限
            await kernelSUAPI.chmod(this.configPath, '644');
            await kernelSUAPI.chown(this.configPath, 'system:system');

            console.log(`配置文件已恢复: ${targetBackup}`);

        } catch (error) {
            console.error('恢复备份失败:', error);
            throw new Error(`恢复备份失败: ${error.message}`);
        }
    }

    /**
     * 清理旧备份文件
     * @param {number} keepCount - 保留的备份数量
     */
    async cleanOldBackups(keepCount = 10) {
        try {
            const backups = await this.getBackupList();
            
            if (backups.length <= keepCount) {
                return;
            }

            // 删除多余的备份
            const toDelete = backups.slice(keepCount);
            for (const backup of toDelete) {
                await exec(`rm -f "${backup.path}"`);
                console.log(`已删除旧备份: ${backup.filename}`);
            }

        } catch (error) {
            console.warn('清理旧备份时出现警告:', error.message);
        }
    }

    /**
     * 获取文件信息
     * @returns {Object} 文件信息
     */
    async getFileInfo() {
        try {
            const exists = await this.checkConfigFileExists();
            if (!exists) {
                return null;
            }

            const result = await exec(`stat "${this.configPath}"`);
            if (result.errno !== 0) {
                throw new Error('获取文件信息失败');
            }

            // 解析stat输出
            const statOutput = result.stdout;
            const sizeMatch = statOutput.match(/Size:\s+(\d+)/);
            const modifyMatch = statOutput.match(/Modify:\s+([^\n]+)/);

            return {
                path: this.configPath,
                size: sizeMatch ? parseInt(sizeMatch[1]) : 0,
                lastModified: modifyMatch ? modifyMatch[1].trim() : 'Unknown',
                exists: true
            };

        } catch (error) {
            console.error('获取文件信息失败:', error);
            return null;
        }
    }

    /**
     * 验证文件完整性
     * @param {string} filePath - 文件路径
     * @returns {boolean} 文件是否完整
     */
    async validateFileIntegrity(filePath = null) {
        try {
            const targetPath = filePath || this.configPath;
            
            // 检查文件是否存在且不为空
            const result = await exec(`test -f "${targetPath}" && test -s "${targetPath}"`);
            if (result.errno !== 0) {
                return false;
            }

            // 检查是否为有效的XML文件
            const xmlCheck = await exec(`head -1 "${targetPath}"`);
            if (xmlCheck.errno !== 0 || !xmlCheck.stdout.includes('<?xml')) {
                return false;
            }

            return true;

        } catch (error) {
            console.error('文件完整性验证失败:', error);
            return false;
        }
    }
}
